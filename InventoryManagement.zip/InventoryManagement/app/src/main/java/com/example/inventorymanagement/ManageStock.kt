package com.example.inventorymanagement

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.manage_stock.*
import java.lang.Exception


class ManageStock:Activity(), View.OnClickListener, AdapterView.OnItemSelectedListener {
    val dbh = DBHandler(this, null)
    private val category = arrayListOf<String>("Chips", "Drinks", "Sports", "Produce")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.manage_stock)
        registerForContextMenu(stockCategorySpinner)
        val adp = ArrayAdapter(this, android.R.layout.simple_spinner_item, category)
        adp.setDropDownViewResource(android.R.layout.simple_list_item_single_choice)
        stockCategorySpinner.adapter = adp
        stockCategorySpinner.onItemSelectedListener = this

        stockId.isEnabled = false
        btnSave.setOnClickListener(this)
        btnCancel.setOnClickListener(this)
        val extras = intent.extras
        if(extras!=null){
            val inventory:Inventory = dbh.getInventory(extras.getInt("ID"))
            stockCategorySpinner.setSelection(category.indexOf(inventory.category))
            stockName.setText(inventory.name)
            stockQuantity.setText(inventory.quantity)
            stockId.setText(inventory.id.toString())
        }
    }

    override fun onClick(v: View) {
        when(v.id){
            R.id.btnSave ->{
                var cid:Int = 0
                try{
                    cid = stockId.text.toString().toInt()
                }catch (e:Exception){
                    cid = 0
                }
                if(cid == 0){
                    addInventory()
                }else{
                    editInventory()
                }
            }
            R.id.btnCancel ->{
                goBack()
            }
        }
    }

    private fun editInventory() {
        val inventory = Inventory()
        inventory.name = stockName.text.toString()
        inventory.quantity = stockQuantity.text.toString()
        inventory.id = stockId.text.toString().toInt()
        inventory.category = category.get(stockCategorySpinner.selectedItemPosition)
        dbh.updateInventory(inventory)
        Toast.makeText(this,"Inventory has been updated", Toast.LENGTH_LONG).show()
        goBack()
    }

    private fun addInventory() {
        val inventory = Inventory()
        inventory.category = category.get(stockCategorySpinner.selectedItemPosition)
        inventory.name = stockName.text.toString().toUpperCase()
        inventory.quantity = stockQuantity.text.toString()
        dbh.addInventory(inventory)
        Toast.makeText(this,"New stock has been added to inventory",Toast.LENGTH_LONG).show()
        goBack()
    }

    private fun goBack() {
        val mainAct = Intent(this, MainActivity::class.java)
        startActivity(mainAct)
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        initAdapter(category[position])
    }

    private fun initAdapter(s: String) {

    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

}