package com.example.inventorymanagement

import android.content.ContentValues
import android.content.Context
import  android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.prefs.PreferencesFactory


class DBHandler(context:Context?,factory: SQLiteDatabase.CursorFactory?):SQLiteOpenHelper(context, DBName, factory, DBVersion) {
    //table and field names
    private val TableName:String = "Stock"
    private val KeyID:String = "ID"
    private val KeyName:String = "NAME"
    private val KeyQuantity:String = "QUANTITY"
    private val KeyCategory:String = "CATEGORY"
    companion object{
        const val DBName = "StockDB"
        const val DBVersion = 6
    }
    override fun onCreate(db: SQLiteDatabase){
        val createTable:String = "CREATE TABLE $TableName($KeyID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$KeyCategory TEXT, $KeyName TEXT, $KeyQuantity TEXT)"
        db.execSQL(createTable)
        val cv = ContentValues()
        cv.put(KeyCategory, "CHIPS")
        cv.put(KeyName,"SMITH'S CHIPS 90G")
        cv.put(KeyQuantity,"20")
        db.insert(TableName, null, cv)
        val cv1 = ContentValues()
        cv1.put(KeyCategory, "DRINKS")
        cv1.put(KeyName,"ORANGE JUICE")
        cv1.put(KeyQuantity,"8")
        db.insert(TableName, null, cv1)
        val cv2 = ContentValues()
        cv2.put(KeyCategory, "SPORTS")
        cv2.put(KeyName,"SOCCER BALL")
        cv2.put(KeyQuantity,"3")
        db.insert(TableName, null, cv2)
        val cv3 = ContentValues()
        cv3.put(KeyCategory, "PRODUCE")
        cv3.put(KeyName,"APPLE")
        cv3.put(KeyQuantity,"10")
        db.insert(TableName, null, cv3)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int){
        db.execSQL("DROP TABLE IF EXISTS $TableName")
        onCreate(db)
    }

    fun getInventory(id: Int): Inventory {
        val inventory = Inventory()
        val db = this.readableDatabase
        val cursor = db.query(TableName, arrayOf(KeyID, KeyCategory, KeyName, KeyQuantity), "$KeyID=?", arrayOf(id.toString()),
            null, null, null)
        if(cursor!=null){
            cursor.moveToFirst()
            inventory.id = cursor.getInt(0)
            inventory.category = cursor.getString(1)
            inventory.name = cursor.getString(2)
            inventory.quantity = cursor.getString(3)
        }
        cursor.close()
        db.close()
        return inventory
    }

    fun getAllStock(): ArrayList<Inventory> {
        val inventoryList = ArrayList<Inventory>()
        val getallrecords = "SELECT * FROM $TableName WHERE $KeyCategory like \'%Chips%\'"
        val db = this.readableDatabase
        val cursor = db.rawQuery(getallrecords, null)
        if(cursor!=null) {
            while (cursor.moveToNext()) {
                val inventory = Inventory()

                inventory.id = cursor.getInt(0)
                inventory.category = cursor.getString(1)
                inventory.name = cursor.getString(2)
                inventory.quantity = cursor.getString(3)
                inventoryList.add(inventory)
            }
        }
        cursor.close()
        db.close()
        return inventoryList
    }

    fun deleteInventory(id: Int) {
        val db = this.writableDatabase
        db.delete(TableName, "$KeyID=?", arrayOf(id.toString()))
        db.close()
    }

    fun updateInventory(inventory: Inventory) {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(KeyCategory, inventory.category)
        cv.put(KeyName, inventory.name)
        cv.put(KeyQuantity, inventory.quantity)
        db.update(TableName, cv, "$KeyID=?", arrayOf(inventory.id.toString()))
        db.close()
    }

    fun addInventory(inventory: Inventory) {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(KeyCategory, inventory.category).toString().toUpperCase()
        cv.put(KeyName, inventory.name).toString().toUpperCase()
        cv.put(KeyQuantity, inventory.quantity)
        db.insert(TableName, null, cv)
        db.close()
    }

    fun getItemsByCategory(category: String): ArrayList<Inventory> {
        val inventoryList = ArrayList<Inventory>()
        val getallrecords = "SELECT * FROM $TableName WHERE $KeyCategory like \'%$category%\'"
        val db = this.readableDatabase
        val cursor = db.rawQuery(getallrecords, null)
        if(cursor!=null) {
            while (cursor.moveToNext()) {
                val inventory = Inventory()

                inventory.id = cursor.getInt(0)
                inventory.category = cursor.getString(1)
                inventory.name = cursor.getString(2)
                inventory.quantity = cursor.getString(3)
                inventoryList.add(inventory)
            }
        }
        cursor.close()
        db.close()
        return inventoryList
    }
}
