package com.example.inventorymanagement

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.manage_stock.*
import kotlinx.android.synthetic.main.manage_stock.view.*
import java.lang.Exception

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    val category = arrayListOf<String>("Chips", "Drinks", "Sports", "Produce")
    val dbh = DBHandler(this, null)
    var stockList: MutableList<String> = arrayListOf()
    var idsList: MutableList<Int> = arrayListOf()
    val ITEMADD:Int = Menu.FIRST+1
    val ITEMDELETE:Int = Menu.FIRST+2
    val ITEMEDIT:Int = Menu.FIRST+3


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        registerForContextMenu(stockListView)
        val adp = ArrayAdapter(this, android.R.layout.simple_spinner_item, category)
        adp.setDropDownViewResource(android.R.layout.simple_list_item_single_choice)
        spinnerListView.adapter=adp
        spinnerListView.onItemSelectedListener = this
        initAdapter(category.toString())
    }

    private fun initAdapter(category: String) {
        try {
            //clear all the values
            stockList.clear()
            idsList.clear()
            //read all contacts and put in list (CLASS EXAMPLE)
            for (inventory in dbh.getItemsByCategory(category)) {
                idsList.add(inventory.id)
                stockList.add("${inventory.name} \n${inventory.quantity}")
            }
            val adp = ArrayAdapter(this, android.R.layout.simple_list_item_1, stockList)

            stockListView.adapter = adp

        } catch (e: Exception) {
            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        
        when (item.itemId) {
            ITEMADD -> {
                val managestock = Intent(this, ManageStock::class.java)
                startActivity(managestock)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(Menu.NONE, ITEMADD, Menu.NONE, "ADD")
        return super.onCreateOptionsMenu(menu)
    }
    override fun onCreateContextMenu(menu: ContextMenu, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu.add(Menu.NONE, ITEMDELETE, Menu.NONE, "DELETE")
        menu.add(Menu.NONE, ITEMEDIT, Menu.NONE, "EDIT")
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        when (item.itemId) {
            ITEMDELETE -> {
                dbh.deleteInventory(idsList[info.position])
                Toast.makeText(this, "Item has been deleted", Toast.LENGTH_LONG).show()
                initAdapter(category[spinnerListView.selectedItemPosition])
            }
            ITEMEDIT -> {
                val manage_stock = Intent(this, ManageStock::class.java)
                manage_stock.putExtra("ID", idsList[info.position])
                startActivity(manage_stock)
            }
        }
        return super.onContextItemSelected(item)
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
       initAdapter(category[position])
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }
    override fun onResume() {
        super.onResume()
        initAdapter(category.toString())
    }
}
