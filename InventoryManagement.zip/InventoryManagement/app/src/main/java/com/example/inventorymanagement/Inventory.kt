package com.example.inventorymanagement

class Inventory {
    var id:Int = 0
    var category: String? = null
    var name:String? = null
    var quantity:String? = null

    constructor()
    constructor(name:String){
        this.name=name
    }
    constructor(id:Int, category: String, name: String, quantity:String){
        this.id=id
        this.category=category
        this.name=name
        this.quantity=quantity
    }
}
